# Diagrams for the A2A Project

## Explanation

Due to the limitations of the current environment, I was unable to directly generate SVG files for the C4 and sequence diagrams using the Mermaid CLI. The primary issue encountered was the unavailability of required system libraries (like `libglib-2.0.so.0`) needed by the headless Chrome browser that the Mermaid CLI uses internally.

However, I have successfully generated the Mermaid code for both diagrams. This document provides the Mermaid code and instructions on how you can generate the SVG files yourself, either using online editors or by installing the Mermaid CLI in a suitable local environment.

## C4 Diagram

The following Mermaid code represents the C4 diagram for the A2A project, which outlines the system's context, containers, and components:
```
mermaid
graph TD
    subgraph "System Context"
        A[User]
        B[Agent]
        C[AgentFramework]
        D((Agent2Agent (A2A) System))
        A -->|Uses (HTTP)| D
        B -->|Communicates with (A2A Protocol)| D
        C -->|Integrates with (A2A Protocol)| D
    end

    subgraph "Container Diagram"
        E[AgentCard_DB]
        F[A2A_Server]
        G[A2A_Client]
        H[MultiAgentWebApp]
        E((Agent Card Database))
        F((A2A Server))
        G((A2A Client))
        H((Multi-Agent Web App))
        G -->|Sends task requests (A2A Protocol)| F
        F -->|Retrieves agent metadata (HTTP)| E
        F -->|Communicates with agent (Agent framework specific)| B
        H -->|Interact with Agents (HTTP)| F
    end

    subgraph "Component Diagram (A2A Server)"
        I[Task_Manager]
        J[Message_Handler]
        K[AgentCard_Handler]
        L[Streaming_Handler]
        M[Push_Notification]
        I((Task Manager))
        J((Message Handler))
        K((Agent Card Handler))
        L((Streaming Handler))
        M((Push Notification))
        F -->|Manages tasks| I
        F -->|Handles messages| J
        F -->|Manages agent cards| K
        F -->|Handles streaming| L
        F -->|Manage push notifications| M
    end
    style E fill:#ccf,stroke:#333,stroke-width:2px
    style F fill:#ccf,stroke:#333,stroke-width:2px
    style G fill:#ccf,stroke:#333,stroke-width:2px
    style H fill:#ccf,stroke:#333,stroke-width:2px
    style I fill:#cfc,stroke:#333,stroke-width:2px
    style J fill:#cfc,stroke:#333,stroke-width:2px
    style K fill:#cfc,stroke:#333,stroke-width:2px
    style L fill:#cfc,stroke:#333,stroke-width:2px
    style M fill:#cfc,stroke:#333,stroke-width:2px
    style A fill:#fcc,stroke:#333,stroke-width:2px
    style B fill:#fcc,stroke:#333,stroke-width:2px
    style C fill:#fcc,stroke:#333,stroke-width:2px
    style D fill:#fcc,stroke:#333,stroke-width:2px
```
## Sequence Diagram

The following Mermaid code represents the sequence diagram for the A2A project, illustrating the interaction flow between the User, A2A Client, A2A Server, and Agent:
```
mermaid
sequenceDiagram
    participant User
    participant A2A_Client
    participant A2A_Server
    participant Agent
    participant AgentCard

    User->>A2A_Client: initiate task
    activate A2A_Client
    activate A2A_Server
    A2A_Client->>A2A_Server: GET /.well-known/agent.json
    activate AgentCard
    A2A_Server-->>AgentCard: returns agent card
    deactivate AgentCard
    A2A_Client->>A2A_Server: POST /tasks/send {message}
    activate Agent
    A2A_Server->>Agent: process task
    activate AgentCard
    Agent-->>A2A_Server: response / artifact / input required
    A2A_Server->>AgentCard: Update Task status
    deactivate AgentCard
    A2A_Server-->>A2A_Client: Task Status update / Artifact
    deactivate Agent
    A2A_Client-->>User: display information

    alt input required
        User->>A2A_Client: send message
        A2A_Client->>A2A_Server: POST /tasks/send {message}
        activate Agent
        A2A_Server->>Agent: process task
        Agent-->>A2A_Server: response / artifact
        A2A_Server-->>A2A_Client: Task Status update / Artifact
        deactivate Agent
        A2A_Client-->>User: display information
    else completed
        A2A_Server-->>A2A_Client: Task completed
        A2A_Client-->>User: final information
    end
    deactivate A2A_Server
    deactivate A2A_Client
```
## Generating SVG Files from Mermaid Code

You can use the following methods to generate the SVG diagrams from the provided Mermaid code:

### 1. Online Editors

1.  **Copy the Code:** Copy the Mermaid code from the code block above.
2.  **Open an Online Editor:** Go to one of the following Mermaid online editors:
    *   [Mermaid Live Editor](https://mermaid.live/)
    *   [Mermaid Chart](https://mermaid-chart.com/)
3.  **Paste and Render:** Paste the copied code into the editor. The diagram will render automatically.
4.  **Download SVG:** Look for a "Download" or "Export" option to download the rendered diagram as an SVG file.

### 2. Mermaid CLI (Local Installation)

1.  **Install Mermaid CLI:** If you have Node.js and npm installed, install the Mermaid CLI globally:
```
bash
    npm install -g @mermaid-js/mermaid-cli
    
```
2.  **Save Code to Files:** Save the Mermaid code to `.mmd` files (e.g., `c4.mmd` and `sequence.mmd`).
3.  **Generate SVGs:** Use the `mmdc` command to generate the SVG files:
```
bash
    mmdc -i c4.mmd -o c4.svg
    mmdc -i sequence.mmd -o sequence.svg
    
```
Replace `c4.mmd` and `sequence.mmd` with your respective file names.

By following these instructions, you can easily obtain the SVG diagrams for the A2A project.