package com.a2a.client;

import com.a2a.common.request.A2ARequest;
import com.a2a.common.response.A2AResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class Client {
    private final RestTemplate restTemplate;
    private final String baseUrl = "http://localhost:8080";

    @Autowired
    public Client(RestTemplateBuilder restTemplateBuilder) {
        this.restTemplate = restTemplateBuilder.build();
    }

    public A2AResponse sendRequest(A2ARequest request) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<A2ARequest> entity = new HttpEntity<>(request, headers);
        return restTemplate.postForObject(baseUrl, entity, A2AResponse.class);
    }
}