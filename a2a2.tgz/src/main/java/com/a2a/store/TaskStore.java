package com.a2a.store;

public interface TaskStore {
    TaskAndHistory load(String taskId);
    void save(TaskAndHistory taskAndHistory);
}