package com.a2a.store;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public class InMemoryTaskStore implements TaskStore {
    private final Map<String, TaskAndHistory> tasks = new ConcurrentHashMap<>();

    @Override
    public TaskAndHistory load(String taskId) {
        return tasks.get(taskId);
    }

    @Override
    public void save(TaskAndHistory taskAndHistory) {
        tasks.put(taskAndHistory.task().id(), taskAndHistory);
    }
}