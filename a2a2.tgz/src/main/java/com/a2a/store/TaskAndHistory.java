package com.a2a.store;

import com.a2a.common.model.Task;
import com.a2a.common.model.Message;
import java.util.List;

public record TaskAndHistory(
    Task task,
    List<Message> history
) {}