package com.a2a.exception;

import com.a2a.common.response.JSONRPCError;

public interface Error{
	public JSONRPCError toJSONRPCError();
}