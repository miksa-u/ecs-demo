package com.a2a.exception;

        import com.a2a.common.response.JSONRPCError;

public class A2AException extends RuntimeException implements Error{
    private final Integer     code;
    private String taskId;
    private final Object data;
    public A2AException(Integer code, String message, Object data) {
        super(message);
        this.code = code;
        this.data = data;
    }

    public A2AException(Integer code, String message) {
        super(message);
        this.code = code;
        this.data = null;
    }

    public Integer getCode() {
        return code;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public Object getData() {
        return data;
    }
    @Override
    public JSONRPCError    toJSONRPCError() {
        return new JSONRPCError(code, getMessage(), data);
    }
    public static A2AException invalidRequest(String message) {
        return new A2AException(-32600, message);
    }

    public static A2AException taskNotFound(String taskId) {
        return new A2AException(-32001, String.format("Task '%s' not found.", taskId));
    }
    public static A2AException methodNotFound(String method) {
        return new A2AException(-32601, String.format("Method '%s' not found.", method));
    }
    public static A2AException internalError(String message) {
        return new A2AException(-32603, message);
    }
    public static A2AException invalidParams(String message) {
        return new A2AException(-32602, message);
    }
    public static A2AException parseError(String message) {
        return new A2AException(-32700, message);
    }
}