package com.a2a.common.response;

import com.a2a.common.request.TaskQueryParams;

public record TaskResubscriptionRequest(
    String id,
    String jsonrpc,
    String method,
    TaskQueryParams params
) implements com.a2a.common.request.A2ARequest{}