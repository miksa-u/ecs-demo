package com.a2a.common.request;

import com.a2a.common.model.Message;

import java.util.Map;

public record TaskSendParams(
    String id,
    String sessionId,
    Message message,
    PushNotificationConfig pushNotification,
    Integer historyLength,
    Map<String, Object> metadata
) {}