package com.a2a.common.request;

import java.util.Map;

public record TaskQueryParams(
    String id,
    Map<String, Object> metadata,
    Integer historyLength
) {}