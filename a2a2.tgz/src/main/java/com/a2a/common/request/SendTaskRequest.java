package com.a2a.common.request;

public record SendTaskRequest(
    String id,
    String jsonrpc,
    String method,
    TaskSendParams params
) implements A2ARequest{}