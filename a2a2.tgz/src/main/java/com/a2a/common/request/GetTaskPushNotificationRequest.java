package com.a2a.common.request;

public record GetTaskPushNotificationRequest(
    String id,
    String jsonrpc,
    String method,
    TaskIdParams params
) implements A2ARequest{}