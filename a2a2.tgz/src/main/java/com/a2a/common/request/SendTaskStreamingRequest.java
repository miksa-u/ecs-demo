package com.a2a.common.response;

import com.a2a.common.request.TaskSendParams;

public record SendTaskStreamingRequest(
    String id,
    String jsonrpc,
    String method,
    TaskSendParams params
) implements com.a2a.common.request.A2ARequest{}