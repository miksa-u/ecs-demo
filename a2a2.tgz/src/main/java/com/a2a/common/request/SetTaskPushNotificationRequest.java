package com.a2a.common.response;

import com.a2a.common.request.TaskPushNotificationConfig;

public record SetTaskPushNotificationRequest(
    String id,
    String jsonrpc,
    String method,
    TaskPushNotificationConfig params
) implements com.a2a.common.request.A2ARequest{}