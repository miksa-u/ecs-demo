package com.a2a.common.request;

import com.a2a.common.exception.AuthenticationInfo;

public record PushNotificationConfig(
    String url,
    String token,
    AuthenticationInfo authentication
) {}