package com.a2a.common.request;

import java.util.Map;

public record TaskIdParams(
    String id,
    Map<String, Object> metadata
) {}