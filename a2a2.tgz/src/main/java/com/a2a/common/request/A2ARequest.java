package com.a2a.common.request;

public interface A2ARequest {}