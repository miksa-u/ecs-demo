package com.a2a.common.request;

public record JSONRPCRequest(String id, String jsonrpc, String method, Object params) implements A2ARequest{}