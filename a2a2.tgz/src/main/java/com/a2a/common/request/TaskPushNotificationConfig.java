package com.a2a.common.request;

public record TaskPushNotificationConfig(
    String id,
    PushNotificationConfig pushNotificationConfig
) {}