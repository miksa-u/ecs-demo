package com.a2a.common.request;

public record GetTaskRequest(
    String id,
    String jsonrpc,
    String method,
    TaskQueryParams params
) implements A2ARequest{}