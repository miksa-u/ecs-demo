package com.a2a.common.model;

import java.util.Map;

public record TextPart(
    String type,
    String text,
    Map<String, Object> metadata
) implements Part {}