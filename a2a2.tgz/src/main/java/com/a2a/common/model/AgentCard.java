package com.a2a.common.model;

import java.util.List;

public record AgentCard(
    String name,
    String description,
    String url,
    AgentProvider provider,
    String version,
    String documentationUrl,
    AgentCapabilities capabilities,
    AgentAuthentication authentication,
    List<String> defaultInputModes,
    List<String> defaultOutputModes,
    List<AgentSkill> skills
) {}