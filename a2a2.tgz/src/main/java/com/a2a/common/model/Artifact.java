package com.a2a.common.model;

import java.util.List;
import java.util.Map;

public record Artifact(
    String name,
    String description,
    List<Part> parts,
    Integer index,
    Boolean append,
    Map<String, Object> metadata,
    Boolean lastChunk
) {}