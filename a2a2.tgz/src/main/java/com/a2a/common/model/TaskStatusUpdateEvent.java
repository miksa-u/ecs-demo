package com.a2a.common.model;

import java.util.Map;

public record TaskStatusUpdateEvent(
    String id,
    TaskStatus status,
    Boolean final_,
    Map<String, Object> metadata
) {}