package com.a2a.common.model;

import java.util.Map;

public record TaskArtifactUpdateEvent(
    String id,
    Artifact artifact,
    Boolean final,
    Map<String, Object> metadata
) {}