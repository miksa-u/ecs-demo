package com.a2a.common.model;

public record FileContentBytes(
    String name,
    String mimeType,
    String bytes
) implements FileContent{}