package com.a2a.common.model;

import java.util.Map;

public record DataPart(
    String type,
    Map<String, Object> data,
    Map<String, Object> metadata
) implements Part {}