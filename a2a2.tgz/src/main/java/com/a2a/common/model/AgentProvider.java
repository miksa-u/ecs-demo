package com.a2a.common.model;

public record AgentProvider(
    String organization,
    String url
) {}