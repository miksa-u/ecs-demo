package com.a2a.common.model;

import java.util.List;

public record AgentAuthentication(
    List<String> schemes,
    String credentials
) {}