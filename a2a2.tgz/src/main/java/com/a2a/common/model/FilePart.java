package com.a2a.common.model;

import java.util.Map;

public record FilePart(
    String type,
    FileContent file,
    Map<String, Object> metadata
) implements Part {}