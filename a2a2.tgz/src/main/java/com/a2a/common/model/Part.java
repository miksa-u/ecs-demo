package com.a2a.common.model;

public interface Part{}