package com.a2a.common.model;

import java.util.List;
import java.util.Map;

public record AgentSkill(
    String id,
    String name,
    String description,
    List<String> tags,
    List<String> examples,
    List<String> inputModes,
    List<String> outputModes
) {}