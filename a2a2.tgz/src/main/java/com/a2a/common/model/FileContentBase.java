package com.a2a.common.model;

public record FileContentBase(
    String name,
    String mimeType,
    String bytes,
    String uri
) {}