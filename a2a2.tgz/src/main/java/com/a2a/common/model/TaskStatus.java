package com.a2a.common.model;

public record TaskStatus(
    TaskState state,
    Message message,
    String timestamp
) {}