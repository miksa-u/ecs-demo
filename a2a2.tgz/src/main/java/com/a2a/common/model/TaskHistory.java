package com.a2a.common.model;

import java.util.List;

public record TaskHistory(
    List<Message> messageHistory
) {}