package com.a2a.common.model;

public record FileContentUri(
    String name,
    String mimeType,
    String uri
) implements FileContent{}