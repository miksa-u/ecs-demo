package com.a2a.common.model;

import java.util.List;
import java.util.Map;

public record Message(
    String role,
    List<Part> parts,
    Map<String, Object> metadata
) {}