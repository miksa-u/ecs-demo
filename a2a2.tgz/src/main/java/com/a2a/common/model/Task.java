package com.a2a.common.model;

import java.util.List;
import java.util.Map;

public record Task(
    String id,
    String sessionId,
    TaskStatus status,
    List<Artifact> artifacts,
    Map<String, Object> metadata
) {}