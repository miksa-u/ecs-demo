package com.a2a.common.model;

public record AgentCapabilities(
    Boolean streaming,
    Boolean pushNotifications,
    Boolean stateTransitionHistory
) {}