package com.a2a.common.response;

import com.a2a.common.request.TaskPushNotificationConfig;
import com.a2a.common.exception.A2AError;

public record SetTaskPushNotificationResponse(
    String id,
    String jsonrpc,
    TaskPushNotificationConfig result,
    A2AError error
) implements A2AResponse{}