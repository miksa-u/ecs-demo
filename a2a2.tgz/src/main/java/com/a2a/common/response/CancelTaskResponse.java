package com.a2a.common.response;

import com.a2a.common.model.Task;
import com.a2a.common.exception.A2AError;

public record CancelTaskResponse(
    String id,
    String jsonrpc,
    Task result,
    A2AError error
) implements A2AResponse{}