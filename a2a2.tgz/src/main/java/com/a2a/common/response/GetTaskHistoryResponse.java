package com.a2a.common.response;

import com.a2a.common.model.TaskHistory;
import com.a2a.common.exception.A2AError;

public record GetTaskHistoryResponse(
    String id,
    String jsonrpc,
    TaskHistory result,
    A2AError error
) implements A2AResponse{}