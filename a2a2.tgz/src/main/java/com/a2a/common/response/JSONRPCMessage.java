package com.a2a.common.response;

public record JSONRPCMessage(String id, String jsonrpc) implements A2AResponse{}