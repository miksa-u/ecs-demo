package com.a2a.common.response;

import com.a2a.common.model.TaskStatusUpdateEvent;
import com.a2a.common.model.TaskArtifactUpdateEvent;
import com.a2a.common.exception.A2AError;

public record SendTaskStreamingResponse(
    String id,
    String jsonrpc,
    Object result,
    A2AError error
) implements A2AResponse{}