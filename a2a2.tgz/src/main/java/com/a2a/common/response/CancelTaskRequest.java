package com.a2a.common.response;

import com.a2a.common.request.TaskIdParams;

public record CancelTaskRequest(
    String id,
    String jsonrpc,
    String method,
    TaskIdParams params
) implements com.a2a.common.request.A2ARequest{}