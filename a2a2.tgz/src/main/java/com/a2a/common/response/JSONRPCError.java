package com.a2a.common.response;

public record JSONRPCError(
    Integer code,
    String message,
    Object data
) implements A2AError{}