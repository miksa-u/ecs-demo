package com.a2a.common.response;

public record JSONRPCMessageIdentifier(String id) {}