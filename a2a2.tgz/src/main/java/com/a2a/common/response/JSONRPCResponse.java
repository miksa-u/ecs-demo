package com.a2a.common.response;

public record JSONRPCResponse(
    String id,
    String jsonrpc,
    Object result,
    JSONRPCError error
) implements A2AResponse{}