package com.a2a.common.response;

public interface A2AResponse {}