package com.a2a.common.exception;

public interface A2AError{}