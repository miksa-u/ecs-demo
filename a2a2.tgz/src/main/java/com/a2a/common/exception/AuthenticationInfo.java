package com.a2a.common.exception;

import com.a2a.common.model.AgentAuthentication;

import java.util.Map;
import java.util.List;

public record AuthenticationInfo(
    List<String> schemes,
    String credentials,
    Map<String, Object> additionalProperties
) implements AgentAuthentication{}