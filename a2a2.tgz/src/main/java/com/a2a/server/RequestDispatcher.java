package com.a2a.server;

import com.a2a.common.request.CancelTaskRequest;
import com.a2a.common.request.GetTaskPushNotificationRequest;
import com.a2a.common.request.GetTaskRequest;
import com.a2a.common.request.SendTaskRequest;
import com.a2a.common.request.SendTaskStreamingRequest;
import com.a2a.common.response.A2AResponse;
import com.a2a.common.response.CancelTaskResponse;
import com.a2a.common.response.GetTaskPushNotificationResponse;
import com.a2a.common.response.GetTaskResponse;
import com.a2a.common.response.JSONRPCRequest;
import com.a2a.common.response.SendTaskResponse;
import com.a2a.common.response.SendTaskStreamingResponse;
import com.a2a.exception.A2AException;
import com.a2a.handler.TaskHandler;
import com.a2a.store.TaskStore;
import org.springframework.stereotype.Component;

@Component
public class RequestDispatcher {

    private final TaskStore taskStore;
    private final TaskHandler taskHandler;

    public RequestDispatcher(TaskStore taskStore, TaskHandler taskHandler) {
        this.taskStore = taskStore;
        this.taskHandler = taskHandler;
    }
    public A2AResponse dispatch(JSONRPCRequest request) {
        if (request instanceof SendTaskRequest) {
            return handleSendTask((SendTaskRequest) request);
        } else if (request instanceof GetTaskRequest) {
            return handleGetTask((GetTaskRequest) request);
        } else if (request instanceof CancelTaskRequest) {
            return handleCancelTask((CancelTaskRequest) request);
        }else if (request instanceof SendTaskStreamingRequest) {
            return handleSendTaskStreaming((SendTaskStreamingRequest) request);
        } else if (request instanceof GetTaskPushNotificationRequest) {
            return handleGetTaskPushNotification((GetTaskPushNotificationRequest) request);
        } else {
            throw A2AException.methodNotFound(request.method());
        }
    }

    private A2AResponse handleGetTaskPushNotification(GetTaskPushNotificationRequest request) {
        throw new UnsupportedOperationException();
    }

    private SendTaskStreamingResponse handleSendTaskStreaming(SendTaskStreamingRequest request) {
        throw new UnsupportedOperationException();
    }

    private CancelTaskResponse handleCancelTask(CancelTaskRequest request) {
        throw new UnsupportedOperationException();
    }

    private GetTaskResponse handleGetTask(GetTaskRequest request) {
        throw new UnsupportedOperationException();
    }

    private SendTaskResponse handleSendTask(SendTaskRequest request) {
        throw new UnsupportedOperationException();
    }
}