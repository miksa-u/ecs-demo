package com.a2a.server.utils;

import com.a2a.common.model.Artifact;
import com.a2a.common.model.TaskStatus;
import com.a2a.store.TaskAndHistory;
import java.time.Instant;
import com.a2a.common.model.TaskState;
import com.a2a.common.model.Message;

public class Utils {
    public static String getCurrentTimestamp() {
        return Instant.now().toString();
    }

    public static boolean isTaskStatusUpdate(Object update) {
        if (update instanceof TaskStatus) {
            return true;
        }
        return false;
    }

    public static boolean isArtifactUpdate(Object update) {
        if (update instanceof Artifact) {
            return true;
        }
        return false;
    }
        public static TaskAndHistory applyUpdateToTaskAndHistory(
            TaskAndHistory current,
            Object update
    ) {
        if (isTaskStatusUpdate(update)){
            return applyStatusUpdate(current, (TaskStatus)update);
        } else if (isArtifactUpdate(update)){
            return applyArtifactUpdate(current, (Artifact)update);
        } else {
            throw new UnsupportedOperationException("Unsupported update type");
        }
    }

    private static TaskAndHistory applyStatusUpdate(TaskAndHistory current, TaskStatus update) {
        return new TaskAndHistory(
                new com.a2a.common.model.Task(
                        current.task().id(),
                        current.task().sessionId(),
                        new TaskStatus(
                                update.state(),
                                update.message(),
                                getCurrentTimestamp()
                        ),
                        current.task().artifacts(),
                        current.task().metadata()
                ),
                current.history()
        );
    }

    private static TaskAndHistory applyArtifactUpdate(TaskAndHistory current, Artifact update) {
        throw new UnsupportedOperationException();
    }

    public static boolean isFinalState(TaskState state) {
        return state == TaskState.COMPLETED || state == TaskState.FAILED || state == TaskState.CANCELED || state == TaskState.INPUT_REQUIRED;
    }
}