package com.a2a.server.utils;

import com.a2a.common.model.Message;
import com.a2a.common.model.Task;
import com.a2a.store.TaskAndHistory;

import java.util.List;

public class Context {
    public static TaskAndHistory loadOrCreateTaskAndHistory(String taskId, Message initialMessage, String sessionId, java.util.Map<String, Object> metadata, com.a2a.store.TaskStore taskStore){
        TaskAndHistory data = taskStore.load(taskId);
        boolean needsSave = false;

        if (data == null) {
            Task initialTask = new Task(
                    taskId,
                    sessionId,
                    new com.a2a.common.model.TaskStatus(com.a2a.common.model.TaskState.SUBMITTED, null, Utils.getCurrentTimestamp()),
                    java.util.List.of(),
                    metadata
            );
            List<Message> initialHistory = java.util.List.of(initialMessage);
            data = new TaskAndHistory(initialTask, initialHistory);
            needsSave = true;
        } else {
            List<Message> newHistory = new java.util.ArrayList<>(data.history());
            newHistory.add(initialMessage);
            data = new TaskAndHistory(data.task(), newHistory);
            needsSave = true;
        }
        if (needsSave){
            taskStore.save(data);
        }
        return data;

    }


}