package com.a2a.server;

import com.a2a.common.response.JSONRPCError;
import com.a2a.common.response.JSONRPCResponse;
import com.a2a.exception.A2AException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalErrorController {
    @ExceptionHandler(A2AException.class)
    public ResponseEntity<JSONRPCResponse> handleA2AException(A2AException ex) {
        JSONRPCError error = ex.toJSONRPCError();
        JSONRPCResponse response = new JSONRPCResponse(null, "2.0", null, error);
        return ResponseEntity.ok(response);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<JSONRPCResponse> handleGlobalException(Exception ex) {
        A2AException a2AException = A2AException.internalError(ex.getMessage());
        JSONRPCError error = a2AException.toJSONRPCError();
        JSONRPCResponse response = new JSONRPCResponse(null, "2.0", null, error);
        return ResponseEntity.ok(response);
    }
}