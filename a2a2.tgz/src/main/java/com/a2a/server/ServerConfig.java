package com.a2a.server;

import com.a2a.common.model.AgentCapabilities;
import com.a2a.common.model.AgentCard;
import com.a2a.common.model.AgentProvider;
import com.a2a.common.model.AgentSkill;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Configuration
public class ServerConfig {
    @Bean
    public AgentCard agentCard() {
        return new AgentCard(
                "Example Agent",
                "This is an example agent.",
                "http://example.com",
                new AgentProvider("Example Organization", "http://example.com/provider"),
                "1.0.0",
                "http://example.com/docs",
                new AgentCapabilities(false, false, false),
                null,
                List.of(),
                List.of(),
                List.of(new AgentSkill("exampleSkill", "Example Skill", "This is an example skill.", List.of(), List.of(), List.of(), List.of()))
        );
    }

    @Bean
    public RestTemplate restTemplate(){
        return new RestTemplate();
    }
}