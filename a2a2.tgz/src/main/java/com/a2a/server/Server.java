package com.a2a.server;

import com.a2a.common.model.AgentCard;
import com.a2a.common.request.JSONRPCRequest;
import com.a2a.common.response.A2AResponse;
import com.a2a.common.response.JSONRPCResponse;
import com.a2a.exception.A2AException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
@CrossOrigin
@RequestMapping("/")
public class Server {
    @Autowired
    private RequestDispatcher requestDispatcher;
    @Autowired
    private AgentCard card;
    public static void main(String[] args) {
        SpringApplication.run(Server.class, args);
    }

    @PostMapping
    public ResponseEntity<A2AResponse> endpoint(@RequestBody JSONRPCRequest request) {
        try {
            A2AResponse response = requestDispatcher.dispatch(request);
            return ResponseEntity.ok(response);
        } catch (A2AException ex) {
            return ResponseEntity.ok(ex.toJSONRPCError());
        }
    }
    @GetMapping("/.well-known/agent.json")
    public ResponseEntity<AgentCard> getAgentCard(){
        return ResponseEntity.ok(card);
    }
}