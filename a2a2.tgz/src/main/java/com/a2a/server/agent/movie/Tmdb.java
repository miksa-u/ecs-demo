package com.a2a.server.agent.movie;

import com.a2a.common.model.Task;

import java.util.List;

public class Tmdb {
    private Tmdb(){
        throw new IllegalStateException("Utility class");
    }

    public static List<Task> searchMovies(String query) {
        return List.of();
    }
}