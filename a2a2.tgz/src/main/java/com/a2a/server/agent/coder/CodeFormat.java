package com.a2a.server.agent.coder;

public class CodeFormat {
    private CodeFormat(){
      throw new IllegalStateException("Utility class");
    }
    public static String formatCode(String code) {
        return code;
    }
}