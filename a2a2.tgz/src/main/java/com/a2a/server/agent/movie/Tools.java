package com.a2a.server.agent.movie;

import com.a2a.common.model.Task;

import java.util.List;

public class Tools {
    private Tools(){
        throw new IllegalStateException("Utility class");
    }

    public static List<Task> getTasks(){
      return List.of();
    }
}