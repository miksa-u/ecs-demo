package com.a2a.server.agent.coder;

import com.a2a.common.model.Task;

import java.util.List;

public class Genkit {
    private Genkit(){
      throw new IllegalStateException("Utility class");
    }
    public static List<Task> getTasks(String taskDescription) {
        return List.of();
    }
}