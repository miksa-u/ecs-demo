package com.a2a.handler;

import com.a2a.common.model.Message;
import com.a2a.common.model.TaskStatus;
import com.a2a.common.model.TaskState;
import org.springframework.stereotype.Component;

import java.util.concurrent.Flow;

@Component
public class DefaultTaskHandler implements TaskHandler {

    @Override
    public void subscribe(Flow.Subscriber<? super TaskStatus> subscriber) {
        subscriber.onSubscribe(new Flow.Subscription() {
            @Override
            public void request(long n) {
                subscriber.onNext(new TaskStatus(TaskState.COMPLETED, new Message("agent", java.util.List.of(), java.util.Map.of()), ""));
            }

            @Override
            public void cancel() {

            }
        });

    }
}