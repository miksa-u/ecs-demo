package com.a2a.handler;

import com.a2a.common.model.Part;
import com.a2a.common.model.TaskStatus;
import java.util.concurrent.Flow;

public interface TaskHandler extends Flow.Publisher<Object> {
}