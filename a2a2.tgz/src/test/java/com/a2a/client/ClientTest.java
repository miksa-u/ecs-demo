package com.a2a.client;

import com.a2a.common.model.Message;
import com.a2a.common.request.SendTaskRequest;
import com.a2a.common.request.TaskSendParams;
import com.a2a.common.response.A2AResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import java.util.List;
import java.util.Map;

public class ClientTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private RestTemplateBuilder restTemplateBuilder;

    @InjectMocks
    private Client client;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        when(restTemplateBuilder.build()).thenReturn(restTemplate);
    }

    @Test
    void sendRequest() {
        // Prepare request and mocked response
        Message message = new Message("user", List.of(), Map.of());
        TaskSendParams params = new TaskSendParams("task1", "session1", message, null, 0, Map.of());
        SendTaskRequest sendTaskRequest = new SendTaskRequest("1", "2.0", "tasks/send", params);

        A2AResponse expectedResponse = new A2AResponse("1", "2.0");

        when(restTemplate.postForObject(anyString(), any(), any())).thenReturn(expectedResponse);

        // Call the client
        A2AResponse actualResponse = client.sendRequest(sendTaskRequest);

        // Assertions
        assertThat(actualResponse, is(expectedResponse));
    }
}