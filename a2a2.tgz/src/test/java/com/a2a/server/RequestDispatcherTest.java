package com.a2a.server;

import com.a2a.common.model.Message;
import com.a2a.common.request.CancelTaskRequest;
import com.a2a.common.request.GetTaskRequest;
import com.a2a.common.request.SendTaskRequest;
import com.a2a.common.request.TaskQueryParams;
import com.a2a.common.request.TaskSendParams;
import com.a2a.common.response.CancelTaskResponse;
import com.a2a.common.response.GetTaskResponse;
import com.a2a.common.response.SendTaskResponse;
import com.a2a.exception.A2AException;
import com.a2a.handler.TaskHandler;
import com.a2a.common.model.Task;
import com.a2a.common.model.TaskState;
import com.a2a.store.TaskAndHistory;
import com.a2a.store.TaskStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;
import java.util.List;
import java.util.Map;

public class RequestDispatcherTest {

    @Mock
    private TaskStore taskStore;

    @Mock
    private TaskHandler taskHandler;

    @InjectMocks
    private RequestDispatcher requestDispatcher;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void dispatchSendTaskRequest() {
        Message message = new Message("user", List.of(), Map.of());
        TaskSendParams params = new TaskSendParams("task1", "session1", message, null, 0, Map.of());
        SendTaskRequest request = new SendTaskRequest("1", "2.0", "tasks/send", params);

        SendTaskResponse response = (SendTaskResponse) requestDispatcher.dispatch(request);
        assertThat(response.id(), is("1"));\
        verify(taskHandler, times(1)).subscribe(any());
    }

    @Test
    void dispatchGetTaskRequest() {
        TaskQueryParams params = new TaskQueryParams("task1", Map.of(), 0);
        GetTaskRequest request = new GetTaskRequest("1", "2.0", "tasks/get", params);
        Task task = new Task("task1", "session1", new com.a2a.common.model.TaskStatus(TaskState.WORKING, new Message("agent", java.util.List.of(), java.util.Map.of()),""), List.of(), java.util.Map.of());
        TaskAndHistory taskAndHistory = new TaskAndHistory(task, List.of(new Message("user", java.util.List.of(), java.util.Map.of())));
        when(taskStore.load("task1")).thenReturn(taskAndHistory);
        GetTaskResponse response = (GetTaskResponse) requestDispatcher.dispatch(request);
        assertThat(response.id(), is("1"));
        verify(taskStore, times(1)).load("task1");
    }

    @Test
    void dispatchCancelTaskRequest() {
        // Prepare a task to be cancelled
        Message message = new Message("user", List.of(), Map.of());
        TaskSendParams sendParams = new TaskSendParams("task1", "session1", message, null, 0, Map.of());
        SendTaskRequest sendRequest = new SendTaskRequest("1", "2.0", "tasks/send", sendParams);
        requestDispatcher.dispatch(sendRequest);

        // Cancel the task
        com.a2a.common.request.TaskIdParams cancelParams = new com.a2a.common.request.TaskIdParams("task1", Map.of());
        CancelTaskRequest cancelRequest = new CancelTaskRequest("2", "2.0", "tasks/cancel", cancelParams);
        Task task = new Task("task1", "session1", new com.a2a.common.model.TaskStatus(TaskState.WORKING, new Message("agent", java.util.List.of(), java.util.Map.of()),""), List.of(), java.util.Map.of());
        TaskAndHistory taskAndHistory = new TaskAndHistory(task, List.of(new Message("user", java.util.List.of(), java.util.Map.of())));
        when(taskStore.load("task1")).thenReturn(taskAndHistory);
        CancelTaskResponse cancelResponse = (CancelTaskResponse) requestDispatcher.dispatch(cancelRequest);
        assertThat(cancelResponse.id(), is("2"));
        verify(taskStore, times(1)).load("task1");
    }

    @Test
    void dispatchUnknownMethod() {
        com.a2a.common.response.JSONRPCRequest unknownRequest = new com.a2a.common.response.JSONRPCRequest("1", "2.0", "unknown/method", Map.of());
        assertThrows(A2AException.class, () -> requestDispatcher.dispatch(unknownRequest));
    }
}