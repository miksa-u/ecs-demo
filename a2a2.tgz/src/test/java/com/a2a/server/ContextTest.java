package com.a2a.server;

import com.a2a.common.model.Message;
import com.a2a.common.model.TaskState;
import com.a2a.server.utils.Context;
import com.a2a.store.InMemoryTaskStore;
import com.a2a.store.TaskAndHistory;
import com.a2a.store.TaskStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import java.util.List;
import java.util.Map;
import static java.util.List.of;

public class ContextTest {
    private TaskStore taskStore;
    @BeforeEach
    public void setUp() {
        taskStore = new InMemoryTaskStore();
    }
    @Test
    void loadOrCreateTaskAndHistory_new() {
        String taskId = "task1";
        Message initialMessage = new Message("user", of(), Map.of());
        String sessionId = "session1";
        Map<String, Object> metadata = Map.of();

        TaskAndHistory result = Context.loadOrCreateTaskAndHistory(taskId, initialMessage, sessionId, metadata, taskStore);

        assertThat(result.task().id(), is(taskId));
        assertThat(result.task().sessionId(), is(sessionId));
        assertThat(result.task().status().state(), is(TaskState.SUBMITTED));
        assertThat(result.history().size(), is(1));
        assertThat(result.history().get(0), is(initialMessage));
    }

    @Test
    void loadOrCreateTaskAndHistory_existing() {
        String taskId = "task1";
        Message initialMessage = new Message("user", of(), Map.of());
        String sessionId = "session1";
        Map<String, Object> metadata = Map.of();

        Context.loadOrCreateTaskAndHistory(taskId, initialMessage, sessionId, metadata, taskStore);
        Message newMessage = new Message("agent", of(), Map.of());
        TaskAndHistory result = Context.loadOrCreateTaskAndHistory(taskId, newMessage, sessionId, metadata, taskStore);

        assertThat(result.task().id(), is(taskId));
        assertThat(result.task().sessionId(), is(sessionId));
        assertThat(result.history().size(), is(2));
        assertThat(result.history().get(1), is(newMessage));
    }
}