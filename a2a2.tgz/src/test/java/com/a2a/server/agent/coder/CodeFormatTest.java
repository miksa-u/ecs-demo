package com.a2a.server.agent.coder;

import org.junit.jupiter.api.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

class CodeFormatTest {

    @Test
    void formatCode() {
        String code = "public class Test {}";

        String formattedCode = CodeFormat.formatCode(code);

        assertThat(formattedCode, is(code));
    }
}