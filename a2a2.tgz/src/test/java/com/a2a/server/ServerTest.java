package com.a2a.server;

import com.a2a.common.model.AgentCard;
import com.a2a.common.request.SendTaskRequest;
import com.a2a.common.request.TaskSendParams;
import com.a2a.common.model.Message;
import com.a2a.common.response.A2AResponse;
import com.a2a.common.response.SendTaskResponse;
import com.a2a.handler.TaskHandler;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;

import java.util.List;
import java.util.Map;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ContextConfiguration(classes = ServerConfig.class)
public class ServerTest {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private TaskHandler taskHandler;

    @Autowired
    private RequestDispatcher requestDispatcher;

    @Autowired
    private AgentCard agentCard;

    @Test
    void shouldReturnAgentCard() {
        ResponseEntity<AgentCard> response = this.restTemplate.getForEntity("http://localhost:" + port + "/.well-known/agent.json", AgentCard.class);

        assertThat(response.getStatusCode(), is(HttpStatus.OK));
        assertThat(response.getBody(), notNullValue());
        assertThat(response.getBody().name(), is(agentCard.name()));
    }

    @Test
    void shouldReturnTaskResponse() {
        Message message = new Message("user", List.of(), Map.of());
        TaskSendParams params = new TaskSendParams("task1", "session1", message, null, 0, Map.of());
        SendTaskRequest request = new SendTaskRequest("1", "2.0", "tasks/send", params);
        ResponseEntity<A2AResponse> response = this.restTemplate.postForEntity("http://localhost:" + port, request, A2AResponse.class);

        assertThat(response.getStatusCode(), is(HttpStatus.OK));
        assertThat(response.getBody(), notNullValue());
        assertThat(response.getBody().id(), is("1"));
    }
}