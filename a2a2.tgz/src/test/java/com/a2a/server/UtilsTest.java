package com.a2a.server;

        import com.a2a.common.model.Artifact;
        import com.a2a.common.model.Message;
        import com.a2a.common.model.TaskStatus;
        import com.a2a.common.model.TaskState;
        import com.a2a.server.utils.Utils;
        import com.a2a.store.TaskAndHistory;
        import org.junit.jupiter.api.Test;
        import java.util.List;
        import java.util.Map;
        import static org.hamcrest.MatcherAssert.assertThat;
        import static org.hamcrest.Matchers.*;


public class UtilsTest {

    @Test
    void getCurrentTimestamp() {
        String timestamp = Utils.getCurrentTimestamp();

        assertThat(timestamp, is(org.hamcrest.Matchers.notNullValue()));
    }

    @Test
    void isTaskStatusUpdate() {
        TaskStatus status = new TaskStatus(TaskState.WORKING, new Message("agent", List.of(), Map.of()), Utils.getCurrentTimestamp());
        boolean result = Utils.isTaskStatusUpdate(status);
        assertThat(result, is(true));
    }

    @Test
    void isArtifactUpdate() {
        Artifact artifact = new Artifact("type", "data");
        boolean result = Utils.isArtifactUpdate(artifact);
    }

    @Test
    void applyUpdateToTaskAndHistory_StatusUpdate() {
        com.a2a.common.model.Task task = new com.a2a.common.model.Task("task1", "session1", new TaskStatus(TaskState.SUBMITTED, new Message("agent", Map.of(), Map.of()), Utils.getCurrentTimestamp()), List.of(), Map.of());
        TaskAndHistory current = new TaskAndHistory(task, List.of(new Message("user", Map.of(), Map.of())));
        TaskStatus newStatus = new TaskStatus(TaskState.WORKING, new Message("agent", Map.of(), Map.of()), Utils.getCurrentTimestamp());
        
        TaskAndHistory updated = Utils.applyUpdateToTaskAndHistory(current, newStatus);

        assertThat(updated.task().status().state(), is(TaskState.WORKING));
    }

    @Test
    void isFinalState() {
        assertThat(Utils.isFinalState(TaskState.COMPLETED), is(true));
        assertThat(Utils.isFinalState(TaskState.FAILED), is(true));
        assertThat(Utils.isFinalState(TaskState.CANCELED), is(true));
        assertThat(Utils.isFinalState(TaskState.INPUT_REQUIRED), is(true));
        assertThat(Utils.isFinalState(TaskState.WORKING), is(false));
        assertThat(Utils.isFinalState(TaskState.SUBMITTED), is(false));
    }