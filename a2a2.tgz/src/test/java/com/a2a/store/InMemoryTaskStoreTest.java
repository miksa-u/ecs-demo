package com.a2a.store;

import com.a2a.common.model.Message;
import com.a2a.common.model.Task;
import com.a2a.common.model.TaskState;
import org.junit.jupiter.api.Test;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertNull;
import java.util.List;

public class InMemoryTaskStoreTest {

    @Test
    void saveAndLoad() {
        InMemoryTaskStore store = new InMemoryTaskStore();
        Task task = new Task("task1", "session1", new com.a2a.common.model.TaskStatus(TaskState.WORKING, new Message("agent", java.util.List.of(), java.util.Map.of()),""), List.of(), java.util.Map.of());
        List<Message> history = java.util.List.of(new Message("user", java.util.List.of(), java.util.Map.of()));
        TaskAndHistory taskAndHistory = new TaskAndHistory(task, history);

        store.save(taskAndHistory);
        TaskAndHistory loaded = store.load("task1");

        assertThat(loaded.task().id(), is(task.id()));
        assertThat(loaded.history().size(), is(history.size()));
        assertThat(loaded.task().status().state(), is(task.status().state()));
    }

    @Test
    void loadNonExistent() {
        InMemoryTaskStore store = new InMemoryTaskStore();
        TaskAndHistory loaded = store.load("nonexistent");
        assertNull(loaded);
    }
}