package com.a2a.server.taskmanager;

import com.a2a.common.request.TaskRequest;
import com.a2a.common.response.TaskResponse;
import com.a2a.server.agent.Agent;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
class A2ATaskManagerTest {

  @Mock
  private Agent agent;

  @InjectMocks
  private A2ATaskManager a2ATaskManager;

  @Test
  void onSendTask_ShouldCallAgentProcess() {
    TaskRequest taskRequest = new TaskRequest("Test Message");
    
    String expectedResponse = "Processed: Test Message";
    when(agent.process(anyString())).thenReturn(expectedResponse);
    
    TaskResponse response = a2ATaskManager.onSendTask(taskRequest, agent);
    
    verify(agent).process("Test Message");
    assertThat(response.responseMessage(), is(expectedResponse));
  }
}