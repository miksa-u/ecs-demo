package com.a2a.server;

import com.a2a.common.model.Task;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Optional;
import java.util.UUID;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;

class StoreTest {

    private Store store;

    @BeforeEach
    void setUp() {
        store = Store.getInstance();
        store.put(new Task(UUID.fromString("123e4567-e89b-12d3-a456-426614174000")));
        store.put(new Task(UUID.fromString("123e4567-e89b-12d3-a456-426614174001")));
    }

    @Test
    void put() {
        Task task = new Task();

        UUID id = task.getId();

        store.put(task);

        Optional<Task> result = store.get(id);

        assertThat(result.isPresent(), is(true));
        assertThat(result.get(), is(task));
    }

    @Test
    void get() {
        UUID id = UUID.fromString("123e4567-e89b-12d3-a456-426614174000");

        Optional<Task> result = store.get(id);

        assertThat(result.isPresent(), is(true));
        assertThat(result.get().getId(), is(id));
    }

    @Test
    void getNotExists() {
        UUID id = UUID.randomUUID();

        Optional<Task> result = store.get(id);

        assertThat(result.isPresent(), is(false));
    }

    @Test
    void remove() {
        UUID id = UUID.fromString("123e4567-e89b-12d3-a456-426614174001");

        Task result = store.remove(id);

        assertThat(result, notNullValue());
        assertThat(result.getId(), is(id));
        assertThat(store.get(id).isPresent(), is(false));
    }

    @Test
    void removeNotExists() {
        UUID id = UUID.randomUUID();

        Task result = store.remove(id);

        assertThat(result, nullValue());
    }
}