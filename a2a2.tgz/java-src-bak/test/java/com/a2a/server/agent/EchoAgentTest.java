package com.a2a.server.agent;

import com.a2a.common.exception.A2AException;
import com.a2a.common.model.Message;
import com.a2a.common.model.Task;
import com.a2a.common.request.TaskRequest;
import com.a2a.server.taskmanager.A2ATaskManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

class EchoAgentTest {

    @Mock
    private A2ATaskManager taskManager;

    @InjectMocks
    private EchoAgent echoAgent;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void executeTask_validTask_returnsEchoResponse() {
        TaskRequest taskRequest = new TaskRequest();
        taskRequest.setTaskId(UUID.randomUUID().toString());
        taskRequest.setMessages(List.of(new Message("user", "test message")));
        Task task = new Task(taskRequest);

        when(taskManager.getTask(taskRequest.getTaskId())).thenReturn(task);

        List<Message> result = echoAgent.executeTask(taskRequest);

        assertThat(result).hasSize(2);
        assertThat(result.get(0).getRole()).isEqualTo("user");
        assertThat(result.get(0).getContent()).isEqualTo("test message");
        assertThat(result.get(1).getRole()).isEqualTo("assistant");
        assertThat(result.get(1).getContent()).isEqualTo("test message");
    }

    @Test
    void executeTask_nullTaskRequest_throwsException() {
        assertThatThrownBy(() -> echoAgent.executeTask(null))
                .isInstanceOf(A2AException.class)
                .hasMessageContaining("Task request is null");
    }

    @Test
    void executeTask_emptyMessages_throwsException() {
        TaskRequest taskRequest = new TaskRequest();
        taskRequest.setTaskId(UUID.randomUUID().toString());
        taskRequest.setMessages(List.of());

        Task task = new Task(taskRequest);

        when(taskManager.getTask(taskRequest.getTaskId())).thenReturn(task);

        assertThatThrownBy(() -> echoAgent.executeTask(taskRequest))
                .isInstanceOf(A2AException.class)
                .hasMessageContaining("Task messages are empty");
    }

    @Test
    void executeTask_noTaskFound_throwsException() {

        TaskRequest taskRequest = new TaskRequest();
        taskRequest.setTaskId(UUID.randomUUID().toString());
        taskRequest.setMessages(List.of(new Message("user", "test message")));

        when(taskManager.getTask(taskRequest.getTaskId())).thenReturn(null);

        assertThatThrownBy(() -> echoAgent.executeTask(taskRequest))
                .isInstanceOf(A2AException.class)
                .hasMessageContaining("Task not found");
    }
}