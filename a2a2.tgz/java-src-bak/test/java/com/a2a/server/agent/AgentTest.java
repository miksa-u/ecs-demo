package com.a2a.server.agent;

import com.a2a.common.exception.A2AException;
import com.a2a.common.model.Message;
import com.a2a.common.model.Task;
import com.a2a.common.request.TaskRequest;
import com.a2a.server.taskmanager.A2ATaskManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.is;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.*;

class AgentTest {

    @Mock
    private A2ATaskManager taskManager;

    private Agent agent;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        agent = new EchoAgent(taskManager);
    }

    @Test
    void processTask_validTask_returnsProcessedMessage() {
        
        TaskRequest request = new TaskRequest();
        Task task = new Task(UUID.randomUUID().toString(), request, Collections.emptyList());
        Message processedMessage = new Message();
        when(taskManager.process(task)).thenReturn(processedMessage);
        


        Message result = agent.processTask(task);


        assertThat(result).isSameAs(processedMessage);
        verify(taskManager).process(task);
    }

    @Test
    void processTask_nullTask_throwsA2AException() {
        assertThatThrownBy(() -> agent.processTask(null))
                .isInstanceOf(A2AException.class)
                .hasMessage("Task cannot be null");        
        verifyNoInteractions(taskManager);
    }
}