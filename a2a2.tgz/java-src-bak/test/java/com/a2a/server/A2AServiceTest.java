package com.a2a.server;

import com.a2a.common.exception.A2AException;
import com.a2a.common.exception.JSONParseException;
import com.a2a.common.model.AgentCard;
import com.a2a.common.model.Task;
import com.a2a.common.request.TaskRequest;
import com.a2a.common.response.CancelTaskResponse;
import com.a2a.common.response.GetTaskResponse;
import com.a2a.common.response.SendTaskResponse;
import com.a2a.common.response.TaskResponse;
import com.a2a.server.taskmanager.A2ATaskManager;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.doThrow;

@ExtendWith(MockitoExtension.class)
class A2AServiceTest {

    @Mock
    private A2ATaskManager taskManager;

    @InjectMocks
    private A2AService a2AService;

    private TaskRequest taskRequest;
    private Task task;

    @BeforeEach
    void setUp() {
        taskRequest = new TaskRequest();
        taskRequest.setTaskId(UUID.randomUUID().toString());
        taskRequest.setAgentCard(new AgentCard());
        taskRequest.setParts(List.of());
        task = new Task();
        task.setTaskId(taskRequest.getTaskId());
    }

    @Test
    void sendTask_Success() {
        when(taskManager.sendTask(any())).thenReturn(task);

        SendTaskResponse response = a2AService.sendTask(taskRequest);
        assertThat(response).isNotNull();
        assertThat(response.getTaskId()).isEqualTo(task.getTaskId());
        verify(taskManager).sendTask(taskRequest);
    }

    @Test
    void sendTask_JSONParseException() {

        when(taskManager.sendTask(any())).thenThrow(new JSONParseException());
        assertThatThrownBy(() -> a2AService.sendTask(taskRequest))
                .isInstanceOf(JSONParseException.class);
        verify(taskManager).sendTask(taskRequest);
    }

    @Test
    void sendTask_A2AException() {

        when(taskManager.sendTask(any())).thenThrow(new A2AException("Test A2AException"));
        assertThatThrownBy(() -> a2AService.sendTask(taskRequest))
                .isInstanceOf(A2AException.class)
                .hasMessage("Test A2AException");
        verify(taskManager).sendTask(taskRequest);
    }

    @Test
    void getTask_Success() {

        when(taskManager.getTask(any())).thenReturn(task);
        GetTaskResponse response = a2AService.getTask(task.getTaskId());
        assertThat(response).isNotNull();
        assertThat(response.getTaskId()).isEqualTo(task.getTaskId());
        verify(taskManager).getTask(task.getTaskId());
    }

    @Test
    void getTask_A2AException() {

        when(taskManager.getTask(any())).thenThrow(new A2AException("Test A2AException"));
        assertThatThrownBy(() -> a2AService.getTask(task.getTaskId()))
                .isInstanceOf(A2AException.class)
                .hasMessage("Test A2AException");
        verify(taskManager).getTask(task.getTaskId());
    }

    @Test
    void getTask_JSONParseException() {

        when(taskManager.getTask(any())).thenThrow(new JSONParseException());
        assertThatThrownBy(() -> a2AService.getTask(task.getTaskId()))
                .isInstanceOf(JSONParseException.class);
        verify(taskManager).getTask(task.getTaskId());
    }
    
        @Test
    void cancelTask_Success() {

        when(taskManager.cancelTask(any())).thenReturn(true);
        CancelTaskResponse response = a2AService.cancelTask(task.getTaskId());
        assertThat(response).isNotNull();
        assertThat(response.getIsSuccess()).isTrue();
        verify(taskManager).cancelTask(task.getTaskId());
    }

    @Test
    void cancelTask_A2AException() {

        when(taskManager.cancelTask(any())).thenThrow(new A2AException("Test A2AException"));
        assertThatThrownBy(() -> a2AService.cancelTask(task.getTaskId()))
                .isInstanceOf(A2AException.class)
                .hasMessage("Test A2AException");
        verify(taskManager).cancelTask(task.getTaskId());
    }

    @Test
    void cancelTask_JSONParseException() {

        when(taskManager.cancelTask(any())).thenThrow(new JSONParseException());
        assertThatThrownBy(() -> a2AService.cancelTask(task.getTaskId()))
                .isInstanceOf(JSONParseException.class);
        verify(taskManager).cancelTask(task.getTaskId());
    }

    @Test
    void listAgents_Success() {

        List<AgentCard> agentCards = List.of(new AgentCard(), new AgentCard());
        when(taskManager.listAgents()).thenReturn(agentCards);
        List<AgentCard> response = a2AService.listAgents();
        assertThat(response).isNotNull();
        assertThat(response.size()).isEqualTo(2);
        verify(taskManager).listAgents();
    }

    @Test

    void listAgents_A2AException() {
        when(taskManager.listAgents()).thenThrow(new A2AException("Test A2AException"));
        assertThatThrownBy(() -> a2AService.listAgents())
                .isInstanceOf(A2AException.class)
                .hasMessage("Test A2AException");
        verify(taskManager).listAgents();
    }
    
        @Test

    void listAgents_JSONParseException() {
        when(taskManager.listAgents()).thenThrow(new JSONParseException());
        assertThatThrownBy(() -> a2AService.listAgents())
                .isInstanceOf(JSONParseException.class);
        verify(taskManager).listAgents();
    }
}