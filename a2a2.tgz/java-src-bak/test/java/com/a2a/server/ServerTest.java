package com.a2a.server;

import com.a2a.common.exception.ServerError;
import com.a2a.common.model.AgentCard;
import com.a2a.common.response.SendTaskRequest;
import com.a2a.common.response.SendTaskResponse;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.spy;

class ServerTest {

    @Test
    void sendTask_validRequest_returnsResponse() {
        SendTaskRequest request = new SendTaskRequest();

        SendTaskResponse result = Server.sendTask(request);

        assertThat(result, is(new SendTaskResponse()));
    }

    @Test
    void getAgents_notImplemented_throwsServerError() {
        assertThrows(ServerError.class, Server::getAgents);
    }

    @Test
    void cancelTask_notImplemented_throwsServerError() {
        assertThrows(ServerError.class, () -> Server.cancelTask("taskId"));
    }
}