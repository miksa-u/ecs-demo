package com.a2a.common.response;

public record TaskResponse(String id, String responseMessage, String status){

}