package com.a2a.common.model;

import java.util.List;

public record AgentCard(String name, String description, String url, List<String> capabilities) {}