package com.a2a.common.utils;

public class Utils {

    private Utils() {
        throw new IllegalStateException("Utility class");
    }

    public static String toUpperCase(String text) {
        return text.toUpperCase();
    }

    public static String toLowerCase(String text){
        return text.toLowerCase();
    }
    // Add more utility methods here
}