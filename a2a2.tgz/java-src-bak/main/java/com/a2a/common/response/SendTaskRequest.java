package com.a2a.common.response;

import com.a2a.common.request.TaskSendParams;

public record SendTaskRequest(String jsonrpc, String id, String method, TaskSendParams params) implements JSONRPCRequest {

    public SendTaskRequest {
        if (!"tasks/send".equals(method)) {
            throw new IllegalArgumentException("method must be tasks/send");
        }
    }

}