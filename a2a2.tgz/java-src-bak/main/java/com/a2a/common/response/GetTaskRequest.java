package com.a2a.common.response;

import com.a2a.common.request.TaskQueryParams;

public record GetTaskRequest(String jsonrpc, String id, String method, TaskQueryParams params) implements JSONRPCRequest {
    public GetTaskRequest {
        if (!"tasks/get".equals(method)) {
            throw new IllegalArgumentException("Method must be 'tasks/get'");
        }
    }
}