package com.a2a.common.response;

import com.a2a.common.request.TaskIdParams;

public record GetTaskPushNotificationRequest(String jsonrpc, String id, String method, TaskIdParams params) implements JSONRPCRequestInterface {

    public GetTaskPushNotificationRequest {
        if (!"tasks/pushNotification/get".equals(method)) {
            throw new IllegalArgumentException("Method must be 'tasks/pushNotification/get'");
        }
    }
}