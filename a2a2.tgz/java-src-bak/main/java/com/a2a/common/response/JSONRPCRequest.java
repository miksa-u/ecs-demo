package com.a2a.common.response;

import java.util.UUID;

public record JSONRPCRequest(
        String jsonrpc,
        String id,
        String method,
        Object params
) implements JSONRPCMessage {
    public JSONRPCRequest(String method, Object params) {
        this("2.0", UUID.randomUUID().toString(), method, params);
    }
}