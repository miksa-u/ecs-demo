package com.a2a.common.response;

import com.a2a.common.request.TaskIdParams;
import java.util.UUID;

public record TaskResubscriptionRequest(String jsonrpc, String id, String method, TaskIdParams params) implements JSONRPCRequest {

    public TaskResubscriptionRequest(TaskIdParams params) {
        this("2.0", UUID.randomUUID().toString(), "tasks/resubscribe", params);
    }
}