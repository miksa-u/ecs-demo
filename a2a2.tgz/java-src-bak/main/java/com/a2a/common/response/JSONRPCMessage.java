package com.a2a.common.request;

import java.util.UUID;

public record JSONRPCMessage(String jsonrpc, String id) {
    public JSONRPCMessage {
        if (id == null) {
            id = UUID.randomUUID().toString();
        }
        jsonrpc = "2.0";
    }
}