package com.a2a.common.response;

import com.a2a.common.request.TaskSendParams;

public record SendTaskStreamingRequest(String jsonrpc, String id, String method, TaskSendParams params) implements JSONRPCRequestInterface {

    public SendTaskStreamingRequest {
        if (!"tasks/sendSubscribe".equals(method)) {
            throw new IllegalArgumentException("Method must be tasks/sendSubscribe");
        }
    }
}