package com.a2a.common.response;

import java.util.UUID;

public record JSONRPCResponse(String jsonrpc, String id, Object result, JSONRPCError error) implements java.io.Serializable {
    public JSONRPCResponse {
        if (jsonrpc == null) {
            jsonrpc = "2.0";
        }
        if (id == null) {
            id = UUID.randomUUID().toString();
        }
    }
}