package com.a2a.common.response;

import com.a2a.common.request.TaskPushNotificationConfig;

public record SetTaskPushNotificationRequest(
        String jsonrpc,
        String id,
        String method,
        TaskPushNotificationConfig params
) implements JSONRPCRequest {
    public SetTaskPushNotificationRequest {
        if (!"tasks/pushNotification/set".equals(method)) {
            throw new IllegalArgumentException("Invalid method for SetTaskPushNotificationRequest");
        }
    }
}