package com.a2a.common.response;

import com.a2a.common.request.TaskPushNotificationConfig;

public record SetTaskPushNotificationResponse(
        String jsonrpc,
        String id,
        TaskPushNotificationConfig result,
        JSONRPCError error
) implements JSONRPCResponseInterface {
}