package com.a2a.common.response;

import com.a2a.common.request.TaskIdParams;

public record CancelTaskRequest(String jsonrpc, String id, String method, TaskIdParams params) implements JSONRPCRequest {

    public CancelTaskRequest {
        if (!"tasks/cancel".equals(method)) {
            throw new IllegalArgumentException("Method must be 'tasks/cancel'");
        }
    }

}