package com.a2a.common.response;

public record JSONRPCError(int code, String message, Object data) { 
}