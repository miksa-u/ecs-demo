package com.a2a.common.response;

import com.a2a.common.model.Task;

public record CancelTaskResponse(String jsonrpc, String id, Task result, JSONRPCError error) implements JSONRPCResponseInterface {
}