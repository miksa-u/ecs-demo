package com.a2a.common.response;

import com.a2a.common.model.TaskArtifactUpdateEvent;
import com.a2a.common.model.TaskStatusUpdateEvent;

public record SendTaskStreamingResponse(
        String jsonrpc,
        String id,
        Object result,
        JSONRPCError error
) implements A2AResponse {
    public SendTaskStreamingResponse {
        if (!(result instanceof TaskStatusUpdateEvent) && !(result instanceof TaskArtifactUpdateEvent)) {
            throw new IllegalArgumentException("Result must be either TaskStatusUpdateEvent or TaskArtifactUpdateEvent");
        }
    }
}