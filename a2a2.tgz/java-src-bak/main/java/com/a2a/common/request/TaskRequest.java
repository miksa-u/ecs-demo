package com.a2a.common.request;

public record TaskRequest(String message) {
}