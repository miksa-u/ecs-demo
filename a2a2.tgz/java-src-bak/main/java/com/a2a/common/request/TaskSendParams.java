package com.a2a.common.request;

import com.a2a.common.model.Message;
import com.a2a.common.model.PushNotificationConfig;

import java.util.List;
import java.util.Map;
import java.util.UUID;

public record TaskSendParams(
        String id,
        String sessionId,
        Message message,
        List<String> acceptedOutputModes,
        PushNotificationConfig pushNotification,
        Integer historyLength,
        Map<String, Object> metadata
) {
    public TaskSendParams(String id, Message message, List<String> acceptedOutputModes, PushNotificationConfig pushNotification, Integer historyLength, Map<String, Object> metadata) {
        this(id, UUID.randomUUID().toString(), message, acceptedOutputModes, pushNotification, historyLength, metadata);
    }
}