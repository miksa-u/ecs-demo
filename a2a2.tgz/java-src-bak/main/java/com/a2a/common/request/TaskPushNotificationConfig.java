package com.a2a.common.request;

import com.a2a.common.model.PushNotificationConfig;

public record TaskPushNotificationConfig(String id, PushNotificationConfig pushNotificationConfig) {
}