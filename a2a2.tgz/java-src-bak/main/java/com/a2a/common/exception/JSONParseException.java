package com.a2a.common.exception;

public class JSONParseException extends A2AException {
    public JSONParseException() {
        super(-32700, "Invalid JSON payload", null);
    }
}