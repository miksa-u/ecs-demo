package com.a2a.common.exception;

public class ServerError extends A2AException {
    public ServerError(String message) {
        super(-32000, message, null);
    }
    public ServerError(String message, Object data) {
        super(-32000, message, data);
    }


}