package com.a2a.common.exception;

public class A2AException extends RuntimeException {

    private final Integer code;
    private final Object data;

    public A2AException(String message) {
        super(message);
        this.code = null;
        this.data = null;
    }

    public A2AException(String message, Throwable cause) {
        super(message, cause);
        this.code = null;
        this.data = null;
    }

    public A2AException(Integer code, String message, Object data) {
        super(message);
        this.code = code;
        this.data = data;
    }

    public Integer getCode() {
        return code;
    }

    public Object getData() {
        return data;
    }
}