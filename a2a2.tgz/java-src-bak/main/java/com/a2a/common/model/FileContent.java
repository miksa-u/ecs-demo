package com.a2a.common.types;

public record FileContent(String name, String mimeType, String bytes, String uri) {
}