package com.a2a.common.model;

import java.util.Map;

public record DataPart(String type, Map<String, Object> data, Map<String, Object> metadata) {
    public DataPart {
        if (!"data".equals(type)) {
            throw new IllegalArgumentException("type must be 'data'");
        }
    }
}