package com.a2a.common.model;

import com.a2a.common.types.TaskState;
import java.time.LocalDateTime;

public record TaskStatus(
        TaskState state,
        Message message,
        LocalDateTime timestamp
) {
    public TaskStatus(TaskState state, Message message) {
        this(state, message, LocalDateTime.now());
    }
}