package com.a2a.common.model;

import java.util.List;

public record AuthenticationInfo(List<String> schemes, String credentials) {
}