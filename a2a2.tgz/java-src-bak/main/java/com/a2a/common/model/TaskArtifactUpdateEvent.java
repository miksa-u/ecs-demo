package com.a2a.common.model;

public record TaskArtifactUpdateEvent(String id, Artifact artifact, java.util.Map<String, Object> metadata) {
}