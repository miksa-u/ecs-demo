package com.a2a.common.model;

public interface Part {
}
```

```java
package com.a2a.common.model;

import java.util.Map;

public record TextPart(String type, String text, Map<String, Object> metadata) implements Part {
    public TextPart {
        if (!"text".equals(type)) {
            throw new IllegalArgumentException("Type must be 'text'");
        }
    }
}
```

```java
package com.a2a.common.model;

import java.util.Map;

public record FilePart(String type, FileContent file, Map<String, Object> metadata) implements Part {
    public FilePart {
        if (!"file".equals(type)) {
            throw new IllegalArgumentException("Type must be 'file'");
        }
    }
}
```

```java
package com.a2a.common.model;

import java.util.Map;

public record DataPart(String type, Map<String, Object> data, Map<String, Object> metadata) implements Part {
    public DataPart {
        if (!"data".equals(type)) {
            throw new IllegalArgumentException("Type must be 'data'");
        }
    }
}