package com.a2a.common.model;

import java.util.Map;

public record TaskStatusUpdateEvent(
        String id,
        TaskStatus status,
        boolean finalValue,
        Map<String, Object> metadata) {
}