package com.a2a.common.model;

import java.util.List;

public record Message(String role, List<Part> parts, java.util.Map<String, Object> metadata) {
    public interface Part {}

    public record TextPart(String type, String text, java.util.Map<String, Object> metadata) implements Part {
        public TextPart {
            if (!"text".equals(type)) {
                throw new IllegalArgumentException("type must be 'text'");
            }
        }

        public TextPart(String text, java.util.Map<String, Object> metadata) {
            this("text", text, metadata);
        }
    }

    public record FilePart(String type, FileContent file, java.util.Map<String, Object> metadata) implements Part {
        public FilePart {
            if (!"file".equals(type)) {
                throw new IllegalArgumentException("type must be 'file'");
            }
        }
        public FilePart(FileContent file, java.util.Map<String, Object> metadata) {
            this("file", file, metadata);
        }
    }

    public record DataPart(String type, java.util.Map<String, Object> data, java.util.Map<String, Object> metadata) implements Part {
        public DataPart {
            if (!"data".equals(type)) {
                throw new IllegalArgumentException("type must be 'data'");
            }
        }
        public DataPart(java.util.Map<String, Object> data, java.util.Map<String, Object> metadata) {
            this("data", data, metadata);
        }
    }
    public Message(String role, List<Part> parts) {
        this(role, parts, null);
    }
}