package com.a2a.common.model;

import java.util.Map;

public record FilePart(String type, FileContent file, Map<String, Object> metadata) {
    public FilePart {
        if (!"file".equals(type)) {
            throw new IllegalArgumentException("Type must be 'file'");
        }
    }
    public static final String TYPE = "file";
    public FilePart(FileContent file, Map<String, Object> metadata) {
        this("file", file, metadata);
    }
}