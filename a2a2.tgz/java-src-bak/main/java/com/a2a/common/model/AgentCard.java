package com.a2a.common.model;

import java.util.Objects;

public record AgentCard(String name, String description, String url, String capabilities) {
    @Override
    public String toString() {
        return "AgentCard{" +
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", url='" + url + '\'' +
                ", capabilities='" + capabilities + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AgentCard agentCard = (AgentCard) o;
        return Objects.equals(name, agentCard.name) &&
                Objects.equals(description, agentCard.description) &&
                Objects.equals(url, agentCard.url) &&
                Objects.equals(capabilities, agentCard.capabilities);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, description, url, capabilities);
    }
}
