package com.a2a.common.model;

import java.util.List;

public record PushNotificationConfig(
        String url,
        String token,
        AuthenticationInfo authentication
) {
}