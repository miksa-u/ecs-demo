package com.a2a.server.taskmanager;

import com.a2a.common.exception.A2AException;
import com.a2a.common.model.Task;
import com.a2a.common.model.TaskStatus;
import com.a2a.common.request.TaskRequest;
import com.a2a.common.response.CancelTaskResponse;
import com.a2a.common.response.GetTaskResponse;
import com.a2a.common.response.SendTaskResponse;
import com.a2a.common.response.TaskResponse;
import com.a2a.server.agent.Agent;
import com.a2a.server.Store;
import lombok.extern.slf4j.Slf4j;

import java.util.UUID;


@Slf4j
public class A2ATaskManager {

    private final Store store;
    private final Agent agent;

    private A2ATaskManager() {
        this.store = Store.getInstance();
        this.agent = null;
    }

    public A2ATaskManager(Agent agent) {
        this.store = Store.getInstance();
        this.agent = agent;
    }

    public GetTaskResponse onGetTask(TaskRequest request) {
        log.info("onGetTask: {}", request.id());
        UUID taskId = UUID.fromString(request.id());
        Task task = store.get(taskId).orElseThrow(() -> new A2AException("Task not found"));

        return new GetTaskResponse(task);
    }

    public SendTaskResponse onSendTask(TaskRequest request, Agent agent) {
        log.info("onSendTask: {}", request);
        try {
            Task task = new Task(UUID.randomUUID(), TaskStatus.IN_PROGRESS, request.message());
            store.put(task);

            String response = agent.process(request.message()); //TODO: process should be async and then update Task with response
            task.setMessage(response);
            task.setStatus(TaskStatus.COMPLETED);
            store.put(task);
            return new SendTaskResponse(task);
        } catch (A2AException e) {
            throw new A2AException("Error processing task", e);
        }
    }

    public CancelTaskResponse onCancelTask(TaskRequest request) {
        UUID taskId = UUID.fromString(request.id());
        Task task = store.remove(taskId);
        if(task == null) throw new A2AException("Task not found");
        return new CancelTaskResponse(true);
        log.info("onCancelTask");
        return new TaskResponse(null,null,"onCancelTask");
    }

    public TaskResponse onSetTaskPushNotification(TaskRequest request) {
        log.info("onSetTaskPushNotification");
        return new TaskResponse(null,null,"onSetTaskPushNotification");
    }

    public TaskResponse onGetTaskPushNotification(TaskRequest request) {
        log.info("onGetTaskPushNotification");
        return new TaskResponse(null,null,"onGetTaskPushNotification");
    }

    public TaskResponse onResubscribeToTask(TaskRequest request) {
        log.info("onResubscribeToTask");
        return new TaskResponse(null,null,"onResubscribeToTask");
    }
}