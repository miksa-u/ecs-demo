package com.a2a.server;

import com.a2a.common.exception.ServerError;
import com.a2a.common.model.AgentCard;
import com.a2a.common.request.TaskRequest;
import com.a2a.common.response.SendTaskRequest;
import com.a2a.common.response.SendTaskResponse;

import java.util.List;

public class Server {
    private Server() {
        throw new IllegalStateException("Utility class");
    }


    public static SendTaskResponse sendTask(SendTaskRequest request) {
        // Dummy implementation - replace with actual logic
        return new SendTaskResponse();
    }

    public static List<AgentCard> getAgents() throws ServerError {
        throw new ServerError("Not implemented yet", null);
    }

    public static void cancelTask(String taskId) {
        throw new ServerError("Not implemented yet", null);
    }
}