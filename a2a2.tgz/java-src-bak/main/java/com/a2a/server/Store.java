package com.a2a.server;

import com.a2a.common.model.Task;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public class Store {

    private final Map<UUID, Task> tasks;

    private static class SingletonHolder {
        public static final Store INSTANCE = new Store();
    }

    public static Store getInstance() {
        return SingletonHolder.INSTANCE;
    }

    private Store() {
        tasks = new HashMap<>();
    }

    public Task put(Task task) {
        return tasks.put(task.getId(), task);
    }

    public Optional<Task> get(UUID id) {
        return Optional.ofNullable(tasks.get(id));
    }

    public Task remove(UUID id) {
        return tasks.remove(id);
    }
}