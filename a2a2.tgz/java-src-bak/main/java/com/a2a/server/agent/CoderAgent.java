package com.a2a.server.agent;

import com.a2a.common.exception.A2AException;
import com.a2a.common.model.Message;

public class CoderAgent implements Agent {
    @Override
    public Message process(Message message) throws A2AException {
        return new Message("CoderAgent response: Code processed");
    }
}