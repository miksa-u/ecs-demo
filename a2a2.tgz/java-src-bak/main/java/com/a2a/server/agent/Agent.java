package com.a2a.server.agent;


package com.a2a.server.agent;

import com.a2a.common.exception.A2AException;
import com.a2a.common.model.Task;

public interface Agent {
    String process(Task task) throws A2AException;
}
