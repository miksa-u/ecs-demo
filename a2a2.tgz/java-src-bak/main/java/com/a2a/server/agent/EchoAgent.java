package com.a2a.server.agent;

import com.a2a.common.exception.A2AException;
import com.a2a.common.model.Message;
import com.a2a.common.response.SendTaskResponse;
import com.a2a.common.request.TaskRequest;

public interface Agent {
    SendTaskResponse process(TaskRequest message) throws A2AException;



}
}