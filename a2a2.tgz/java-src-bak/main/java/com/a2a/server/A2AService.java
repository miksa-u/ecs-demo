package com.a2a.server;

import com.a2a.common.exception.A2AException;
import com.a2a.common.model.AgentCard;
import com.a2a.common.request.TaskRequest;
import com.a2a.common.request.TaskSendParams;
import com.a2a.common.response.TaskResponse;
import com.a2a.server.taskmanager.A2ATaskManager;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class A2AService {
    
    private final A2ATaskManager taskManager;
    private final A2ATaskManager a2ATaskManager;
    private AgentCard agentCard;

     private A2AService() {
        throw new IllegalStateException("Utility class");
    }

     public A2AService(A2ATaskManager taskManager, A2ATaskManager a2ATaskManager) {
        this.taskManager = taskManager;
        this.agentCard = new AgentCard("Sample Agent", "http://localhost:8080");
    }

    @PostMapping(path = "/", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public TaskResponse processTask(@RequestBody TaskSendParams request){
        log.info("processTask request : {}", request);
        return a2ATaskManager.onSendTask(request, null);
    }

    @GetMapping(value = "/.well-known/agent.json", produces = MediaType.APPLICATION_JSON_VALUE)
    public AgentCard getAgentCard() {
        log.info("Returning agent card: {}", agentCard);
        return agentCard;
    }

    @GetMapping("/tasks/{taskId}")
    public TaskResponse getTask(@PathVariable String taskId){
        log.info("getTask request for id: {}", taskId);
        return taskManager.onGetTask(taskId);
    }
}


